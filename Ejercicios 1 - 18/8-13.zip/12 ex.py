b = float(input("Introduce el valor de la base menor: "))
B = float(input("Introduce el valor de la base mayor: "))
h = float(input("Introduce el valor de altura: "))

total = ((((B+b)*h)/2))

print(total)

