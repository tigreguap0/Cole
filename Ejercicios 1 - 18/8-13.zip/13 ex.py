v1 = float(input("Introduce el primer valor del cubo: "))

area=(6*(v1*v1))
volumen=(v1*v1*v1)
print("El resultado del area es: ",area,("El voluem es: ",volumen))