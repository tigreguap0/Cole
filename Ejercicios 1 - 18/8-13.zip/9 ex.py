v1 = float(input("introduce tu primer valor: "))
v2 = float(input("introduce tu segundo valor: "))

total = (v1/60)
total3 = (total/60) 
total2 = (v2/60)
total4 = (total2/60) 

print("El resultado es: ",total,"y",total3)
print("El resultado es: ",total2,"y",total4)

input()