v1 = float(input("Introduce el lado del cuadrado: "))

total = (v1*v1*v1)

total2 = (v1+v1+v1+v1)

print("El area del cuadrado es: ",total)
print("El perimetro del cuadrado es: ",total2)
input()