v1 = float(input("Introduce tu primer valor: "))
v2 = float(input("Introduce tu segundo valor: "))

total1 = v1
total2 = v2 // 1
total3 = total1 % 1

print(("El resultado es"),total1,("y el residuo es: "),total2)

if(total1 % 2)  == 0: print("El numero es par")

else:print("El numero es impar")
input()