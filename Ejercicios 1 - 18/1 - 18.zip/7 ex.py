v1 = 0

# Designación de las 2 primeras variables para operar

n1 = float(input("Cuál es tu primer número: "))
n2 = float(input("Cuál es tu segundo número: "))

# Designación de la variable (cm/m/º)

variable = input("Cuál es tu variable: ")

# Resultados

total = (n1 + n2)
total1 = (n1 / n2)
total2 = (n1 * n2)
total3 = (n1 - n2)
total4 = (n1 % n2)
total5 = (n1 // n2)
total6 = (n1 ** n2)

# Los mensajes + los resultados

print("Suma: {:.2f} {}".format(total, variable))
print("Resta: {:.2f} {}".format(total3, variable))
print("Multiplicación: {:.2f} {}".format(total2, variable))
print("División: {:.2f} {}".format(total1, variable))
print("Porcentaje: {:.2f} {}".format(total4, variable))
print("Division entera: {:.2f} {}".format(total5, variable))
print("Exponente: {:.2f} {}".format(total6, variable))
input()
