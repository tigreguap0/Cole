precio_entrada = 12
menores = int(input("Introduce la cantidad de menores: "))
mayores = int(input("introduce la cantida de mayores de edad +18: "))

precios_menores = ((precio_entrada * menores) * 0.5)
precios_menores2 = (precio_entrada - precios_menores)
precios_mayores = ((precio_entrada * mayores) * 0.1)
precios_meyores2 = (precio_entrada - precios_mayores)
print("Menores = El precio total del cine para ",menores,("es de: ",precios_menores2))
print(" Mayores = El precio total del cine para ",mayores,("es de: ",precios_meyores2))

input()