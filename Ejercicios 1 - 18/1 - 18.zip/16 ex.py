
import math
v1 = float(input("Introduce el numero: "))

raiz = math.sqrt(v1)
division_raiz = (raiz / 2 )



print("Raiz: {:.1f}".format(raiz))
print("Division raiz: {:.1f}".format(division_raiz))


input()
