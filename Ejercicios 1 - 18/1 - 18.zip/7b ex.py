#crea un programa en que un usaruio introduzca por teclado un numero de tres cifras y muestre por pantalla la suma de las tres cifras


v1 = input("introduce un numero de tres cifras: ")
v2 = v1[0]
v3 = v1[1]
v4 = v1[2]
total = int(v2)+int(v3)+int(v4)

#INT

print("El resultado es: ",total)

