p1 = input("Introduce tu primera palabra: ")
p2 = input("Introduce tu segunda palabra: ")
p3 = input("Introduce tu tercera palabra: ")
p4 = input("Introduce tu cuarta palabra: ")
p5 = input("Introduce tu quinta")

print(p5,",",p4,",",p3,",",p2,",",p1)
input()
