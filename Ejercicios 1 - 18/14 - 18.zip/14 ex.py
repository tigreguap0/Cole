diametro = float(input("Introduce el diámetro de un círculo: "))

radio = (diametro / 2)
perimetro = (6.283185307179586 * radio)
area = (3.141592653589793 * (radio ** 2))

print("Radio: {:.2f}".format(radio))
print("Perímetro: {:.2f}".format(perimetro))
print("Área: {:.2f}".format(area))

input()
