radio = float(input("Introduce el radio: "))
altura = float(input("Introduce la altura: "))

area_base = (3.141592653589793 * (radio ** 2))
volumen = (area_base * altura)

print("area_base: {:.2f}".format(area_base))
print("Volumen: {:.2f}".format(volumen))


input()
