#Programa un código que permita contar el número de vocales de la siguiente frase: No hay mal que dure cien años
frase = ("No hay mal que dure cien años")
print("Frase")
print(frase)
print("Frase")

a = frase.count("a")
print("Numeros de a",a)

e = frase.count("e")
print("Numeros de e",e)

i = frase.count("i")
print("Numeros de i",i)

o = frase.count("o")
print("Numeros de o",o)

u = frase.count("u")
print("Numeros de u",u)

