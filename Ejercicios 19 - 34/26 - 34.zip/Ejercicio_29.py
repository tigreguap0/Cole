
frase = input("Introduce una frase: ")


longitud = len(frase)
print("La longitud de la frase es:", longitud)
