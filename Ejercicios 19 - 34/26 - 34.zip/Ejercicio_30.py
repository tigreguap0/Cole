
frase = input("Introduce una frase: ")


longitud = len(frase)
print("La longitud de la frase es:", longitud)

if longitud > 11:
    print("Es mayor a 11")

if longitud == 11:
    print("Es igual a 11")

if longitud < 11:
    print("Es menor a 11")