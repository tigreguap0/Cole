frase = ("A quién madruga Dios ayuda")
print("*****FRASE*****")
print("A quién madruga Dios ayuda")
print("*****FRASE*****")
palabra = input("Introduce una palabra de la frase de arriba: ")

x = frase.index(palabra)

print(x)