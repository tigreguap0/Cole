v1 = int(input("introduce tu primer valor: "))
v2 = int(input("introduce tu segundo valor: "))

total = (v1+v2)

print("el resultado es: ",total)
input()
