v1 = float(input("Introduce un numero "))
v2 = float(input("Introduce otro numero "))

total = (v1 + v2)


print("El resultado de la suma es de:",total)