v1 = float(input("Introduce un numero "))
v2 = float(input("Introduce otro numero "))

total = (v1 + v2)
division_total = (total / 3)


print("El resultado de la suma es de:",total)
print(f"El resultado es de ",division_total)