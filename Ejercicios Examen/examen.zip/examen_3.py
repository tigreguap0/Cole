import math

v1 = float(input("Introduce el valor del primer lado del triangulo: "))

raiz = math.sqrt(3)

division = (raiz / 4)

cuadrado = (v1 * v1)

resultado = (division * cuadrado)

print("El resulado es: ",resultado)