v1 = float(input("Introduce tu primer numero: "))
v2 = float(input("Introduce tu segundo numero: "))

if v1 > v2:
    print("El primer numero es mayor")

if v2 > v1:
    print("El segundo numero es mayor")

else:
    print("Son iguales")